angular.module("servicesApp", [])
.factory('MyService', ['$http', function ($http) {
   
     var factory = {};

    factory.uploadpic = function (file) {

    	var fd = new FormData();
			fd.append('fileUploaded', file);

       // return $http.post('http://192.168.100.176:8000/users/upload',fd);

       return $http.post('http://192.168.100.176:8000/users/upload', fd, {
                  transformRequest: angular.identity,
                  headers: {'Content-Type': undefined}
               })
    };


    factory.savedata=function(sdata){

			

    	alert(JSON.stringify(sdata));
    	return $http.post('http://192.168.100.176:8000/users/productsave',sdata);
    };
    return factory;
}])

