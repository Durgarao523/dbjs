scotchApp.controller('aboutController', function($scope,MyService) {
	$scope.categorys='Mobiles';
		$scope.submit = function(){
			
			var obj={
        prname:$scope.productname,
        category:$scope.categorys,
        description:$scope.description,
        picpath:$scope.myFile.name,
        username:$scope.username,
        phonenumber:$scope.phonenum,
        price:$scope.price,
        city:$scope.city
      }

      MyService.uploadpic($scope.myFile)
      .success(function(picdata){
      	alert(JSON.stringify(picdata));
      })
      .error(function(err){
      	alert(err);
      })

      MyService.savedata(obj)
      .success(function(sdata){
      	alert(JSON.stringify(sdata));
      })
      .error(function(err){
      	alert(err);
      })

		}
	});